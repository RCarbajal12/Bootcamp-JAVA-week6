package com.romina.listaestudiantes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListaestudiantesApplicationTests {

	@Test
	void contextLoads() {
	}

}
